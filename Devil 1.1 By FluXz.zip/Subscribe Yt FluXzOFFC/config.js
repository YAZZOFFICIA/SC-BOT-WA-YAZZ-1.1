require("./all/module")

global.owner = "62881012454138" //PAKE NO LU BIAR BISA ADD AKSES
global.namabot = "YAZZ𝙊𝙁𝙁𝘾" //NAMA BOT GANTI
global.namaCreator = "YAZZ𝙊𝙁𝙁𝘾" //NAMA CREATOR GANTI AJA
global.autoJoin = false //NOT CHANGE / JANGAN GANTI
global.antilink = false //NOT CHANGE / JANGAN GANTI
global.versisc = '1.0.0' //NOT CHANGE / JANGAN GANTI
global.codeInvite = ""
global.imageurl = 'https://telegra.ph/file/5acbf4c8495cd60fba160.jpg' //GANTI PP MU MENGGUNAKAN LINK TELEGRA PH
global.isLink = 'https://whatsapp.com/channel/0029VaeOcUT4dTnR6yLfT82V' ///GANTI MENGGUNAKAN LINK GRUBMU YA
global.thumb = fs.readFileSync("./thumb.png") ///NOT CHANGE / JANGAN GANTI
global.audionya = fs.readFileSync("./all/sound.mp3") //NOT CHANGE / JANGAN GANTI
global.packname = "𝙁𝙡𝙪𝙓𝙯𝙊𝙁𝙁𝘾" //GANTI AJ
global.author = "𝙁𝙡𝙪𝙓𝙯𝙊𝙁𝙁𝘾" //GANTI SERAH MU
global.jumlah = "5" ////NOT CHANGE / JANGAN GANTI

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})